package com.example.myappl;

import android.os.AsyncTask;
import android.util.Log;

public class LongOperation extends AsyncTask<Void, Void, String> {

    @Override
    protected String doInBackground(Void... params) {
        try {
            GMailSender sender = new GMailSender("yyy@gmail.com", "xxxxxxx");
            sender.sendMail("New Order Arrived",
                    MainActivity.content,"yyy@gmail.com",
                    "xxx@fordham.edu");
        } catch (Exception e) {
            Log.e("error", e.getMessage(), e);
            return "Email Not Sent";
        }
        return "Email Sent";
    }
    @Override
    protected void onPostExecute(String result) {
        Log.e("LongOperation",result+"");
    }

    @Override
    protected void onPreExecute() {
    }

    @Override
    protected void onProgressUpdate(Void... values) {
    }
}
