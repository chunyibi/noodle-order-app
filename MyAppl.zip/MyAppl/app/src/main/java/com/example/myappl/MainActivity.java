package com.example.myappl;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.ZoomControls;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Security;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import static android.widget.Toast.*;


class GMailSender extends javax.mail.Authenticator {
    private String mailhost = "smtp.gmail.com";
    private String user;
    private String password;
    private Session session;
    static {
        Security.addProvider(new JSSEProvider());
    }
    public GMailSender(String user, String password) {
        this.user = user;
        this.password = password;
        Properties props = new Properties();
        props.setProperty("mail.transport.protocol", "smtp");
        props.setProperty("mail.host", mailhost);
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.port", "465");
        props.put("mail.smtp.socketFactory.port", "465");
        props.put("mail.smtp.socketFactory.class",
                "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.fallback", "false");
        props.setProperty("mail.smtp.quitwait", "false");
        session = Session.getDefaultInstance(props, this);
    }
    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(user, password);
    }
    public synchronized void sendMail(String subject, String body, String sender, String recipients) throws Exception {
        try{
            MimeMessage message = new MimeMessage(session);
            DataHandler handler = new DataHandler(new ByteArrayDataSource(body.getBytes(), "text/plain"));
            message.setSender(new InternetAddress(sender));
            message.setSubject(subject);
            message.setDataHandler(handler);
            if (recipients.indexOf(',') > 0)
                message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipients));
            else
                message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipients));
            Transport.send(message);
        }catch(Exception e){
        }
    }
    public class ByteArrayDataSource implements DataSource {
        private byte[] data;
        private String type;
        public ByteArrayDataSource(byte[] data, String type) {
            super();
            this.data = data;
            this.type = type;
        }
        public ByteArrayDataSource(byte[] data) {
            super();
            this.data = data;
        }
        public void setType(String type) {
            this.type = type;
        }
        public String getContentType() {
            if (type == null)
                return "application/octet-stream";
            else
                return type;
        }
        public InputStream getInputStream() throws IOException {
            return new ByteArrayInputStream(data);
        }
        public String getName() {
            return "ByteArrayDataSource";
        }
        public OutputStream getOutputStream() throws IOException {
            throw new IOException("Not Supported");
        }
    }
}


public class MainActivity extends AppCompatActivity {

    private ImageView image;
    ZoomControls zoomControls;
    CheckBox corn;
    CheckBox egg;
    CheckBox scallion;
    RadioGroup rg;
    Button bReset,bOrder;

    public static String content;
    String ingredients;
    String noodle;
    String flavor;
    RadioButton selectedButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Spinner mySpinner = (Spinner) findViewById(R.id.spinner1);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(MainActivity.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.noodles));
        myAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mySpinner.setAdapter(myAdapter);

        image = findViewById(R.id.image1);

        mySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position) {
                    case 0:
                        image.setImageResource(R.drawable.noodle);
                        break;
                    case 1:
                        image.setImageResource(R.drawable.beef);
                        break;
                    case 2:
                        image.setImageResource(R.drawable.chicken);
                        break;
                    case 3:
                        image.setImageResource(R.drawable.shrimp);
                        break;
                    case 4:
                        image.setImageResource(R.drawable.veggie);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        zoomControls = findViewById(R.id.zoom_controls);
        zoomControls.hide();

        image.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                zoomControls.show();
                return false;
            }
        });
        zoomControls.setOnZoomInClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x= image.getScaleX();
                float y = image.getScaleY();
                image.setScaleX((float)(x+1));
                image.setScaleY((float)(y+1));
                zoomControls.hide();
            }
        });

        zoomControls.setOnZoomOutClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float x = image.getScaleX();
                float y = image.getScaleY();
                if (x==1 && y==1){
                    image.setScaleX(x);
                    image.setScaleY(y);
                }else{
                    image.setScaleX((float)(x-1));
                    image.setScaleY((float)(y-1));
                    zoomControls.hide();
                }
            }
        });

        corn = (CheckBox) findViewById(R.id.cb1);
        egg = (CheckBox) findViewById(R.id.cb2);
        scallion = (CheckBox) findViewById(R.id.cb3);

        corn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(corn.isChecked()){
                    makeText(MainActivity.this, "Corn is checked",
                            LENGTH_SHORT).show();
                }else {
                    makeText(MainActivity.this,"Corn is unchecked",
                            LENGTH_SHORT).show();
                }
            }
        });
        egg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(egg.isChecked()){
                    makeText(MainActivity.this, "Egg is checked",
                            LENGTH_SHORT).show();
                }else {
                    makeText(MainActivity.this,"Egg is unchecked",
                            LENGTH_SHORT).show();
                }
            }
        });
        scallion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(scallion.isChecked()){
                    makeText(MainActivity.this, "Scallion is checked",
                            LENGTH_SHORT).show();
                }else {
                    makeText(MainActivity.this,"Scallion is unchecked",
                            LENGTH_SHORT).show();
                }
            }
        });

        rg=findViewById(R.id.rg);
        bReset=findViewById(R.id.resetButton);
        bOrder=findViewById(R.id.orderButton);
        bReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rg.clearCheck();
                mySpinner.setSelection(0);
                corn.setChecked(false);
                egg.setChecked(false);
                scallion.setChecked(false);
            }
        });


        bOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                noodle =mySpinner.getSelectedItem(). toString();
                if(corn.isChecked()){
                    ingredients=ingredients+"corn";
                };
                if(egg.isChecked()){
                    ingredients=ingredients+"egg";
                };
                if(scallion.isChecked()){
                    ingredients=ingredients+"scallion";
                };

                int selectedId= rg.getCheckedRadioButtonId();
                selectedButton= (RadioButton) findViewById(selectedId);
                flavor=selectedButton.getText().toString();

                content= noodle+" " + ingredients+" " + flavor;

                try {
                    LongOperation l = new LongOperation();
                    l.execute();  //sends the email in background
                    makeText(MainActivity.this, l.get(), LENGTH_SHORT).show();
                } catch (Exception e) {
                    Log.e("SendMail", e.getMessage(), e);
                }
            }
        });
    }
}